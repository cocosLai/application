angular.module('app.controllers', [])

.controller('messagesCtrl', function($scope) {

})

.controller('voicemailCtrl', function($scope) {

})

.controller('cloudTabDefaultPageCtrl', function($scope) {

})

.controller('homeCtrl', function($scope) {

})

// .controller('settings2Ctrl', [$scope, SettingsFactory, function($scope, SettingsFactory) {
//
//   $scope.settings = SettingsFactory.get(); // get settings
//
//   $scope.onEmailNotificationsChange = function(state) {
//       SettingsFactory.setEmailNotifications(state);
//   }
//
// }])


.controller('historyCtrl', function($scope) {

})

.controller('passcodeCtrl', function($scope) {

})

.controller('loginCtrl', function($scope) {

})

.controller('onboardingCtrl', function($scope) {

})

.controller('pageCtrl', function($scope) {

})
